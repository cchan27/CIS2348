userNum = input()


userNumSquared = int(userNum) * int(userNum)
print(userNumSquared)

